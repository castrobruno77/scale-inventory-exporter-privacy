# SCALE Trade Lab v0.1 — RM-002 consolidated

Checkpoint consolidado por VÉRTICE / SCL-DXP-001.

- `tradeup/`: frontend estático integrado ao contrato CAP-SCL-TRADEUP-EVALUATE v1.
- `RM002_QA.md`: estados COMPLETE/PARTIAL/ERROR, QA, limitações e próximo passo.

Este pacote é evidência de trabalho enquanto GitHub write permanece bloqueado. Não representa publicação em `main`.
