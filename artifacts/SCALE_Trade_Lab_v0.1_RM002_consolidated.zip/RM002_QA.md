# RM-002 — Trade Lab v0.1 — QA e limitações

Data: 2026-09-26
Dono: VÉRTICE / SCL-DXP-001

## Escopo do marco
Frontend local do Trade Lab v0.1 consumindo CAP-SCL-TRADEUP-EVALUATE v1, sem cálculo econômico paralelo. Main do GitHub permanece intacta.

## Estados do contrato
- COMPLETE: estrutura e economia exibidas; cards econômicos recebem escala contínua de cor pelo retorno relativo.
- PARTIAL: probabilidades/floats estruturais permanecem visíveis; métricas sem cobertura ficam N/D; cards sem retorno ficam neutros; aviso de cobertura parcial é explícito.
- ERROR: resultados anteriores são ocultados; composição permanece editável; erro do contrato é traduzido em mensagem amigável e o código canônico continua visível.

## QA executado
- `node --check app.js`: PASS.
- Teste determinístico de UI com mocks COMPLETE/PARTIAL/ERROR: PASS após correção de null→0.
- API live COMPLETE: 10× FAMAS | Hexane @0,10 → HTTP 200, economics COMPLETE, input coverage 10/10, output coverage 4/4, expected value 14.008757.
- API live PARTIAL: 10× XM1014 | Blaze Orange @0,10 → HTTP 200, economics PARTIAL, input coverage 0/10, output coverage 1/1, expected value null.
- API live ERROR: inputs vazio → HTTP 400, status ERROR, EXACTLY_10_INPUTS_REQUIRED.
- Regra N/D: PASS — null/undefined/string vazia não são formatados como zero.
- COMPLETE: resumo e outputs visíveis; banner COMPLETE.
- PARTIAL: resumo/outputs estruturais visíveis; economia sem evidência N/D; cards neutros; banner PARTIAL.
- ERROR: resumo/outputs ocultos; banner ERROR inline; composição preservada.
- QA visual anterior do Checkpoint 002: desktop PASS; mobile 390px sem overflow PASS; 10/10 imagens inputs e 4/4 outputs no canário.

## Limitações vigentes
- GitHub write indisponível ao conector (403 Resource not accessible by integration); branch remota ainda não criada.
- Preview remoto não deve ser publicado antes da branch e do gate de publicação.
- Hardening público do endpoint pertence ao BACKEND/VETOR e segue RM-001.
- Inspect continua desabilitado para output hipotético; exige asset/listing real.
- Página canônica de skin, Database, Markets e Patterns são pontes futuras, não funcionalidades ativas na v0.1.
- Copy/mensagem definitiva depende de PRISMA; texto atual é funcional/provisório.

## Próximo passo
Criar `feature/trade-lab-v0.1` assim que GitHub write estiver disponível, versionar exatamente este pacote, preparar preview revisável e só depois considerar publicação material.
