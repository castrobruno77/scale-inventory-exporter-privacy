const API = 'https://ubtojlrfxoxbuvgajeos.supabase.co/functions/v1/tradeup-public';
const state = { slots: Array(10).fill(null), result: null };
const $ = id => document.getElementById(id);
const hasNumber = v => v !== null && v !== undefined && v !== '' && Number.isFinite(Number(v));
const money = v => hasNumber(v) ? `US$ ${Number(v).toFixed(2)}` : 'N/D';
const pct = v => hasNumber(v) ? `${Number(v).toFixed(1)}%` : 'N/D';
const cleanName = n => String(n||'').replace(/^StatTrak™\s+/,'').replace(/^Souvenir\s+/,'').replace(/ \((Factory New|Minimal Wear|Field-Tested|Well-Worn|Battle-Scarred)\)$/,'');
const short = n => cleanName(n).split('|').map(x=>x.trim()).slice(-1)[0]?.slice(0,3).toUpperCase() || 'SKN';
const ERROR_MESSAGES = {
  EXACTLY_10_INPUTS_REQUIRED:'O contrato precisa ter exatamente 10 inputs.',
  MARKET_KEY_AND_FLOAT_REQUIRED:'Há um input sem skin ou float válido.',
  INPUT_NOT_FOUND:'Um dos itens não existe no catálogo canônico.',
  INPUT_NOT_TRADEUP_ELIGIBLE:'Um dos itens não é elegível para trade-up.',
  MIXED_RARITY_NOT_ALLOWED:'Todos os inputs precisam ter a mesma raridade.',
  MIXED_STATTRAK_NOT_ALLOWED:'Normal e StatTrak não podem ser misturados.',
  FLOAT_OUT_OF_RANGE:'Um float está fora da faixa permitida para a skin.',
  NO_ELIGIBLE_OUTPUTS:'Não existem outputs elegíveis para esta composição.',
  INTERNAL_ERROR:'O motor encontrou um erro interno ao avaliar o contrato.'
};
function setResultState(kind,title,detail){
  const box=$('resultState');
  box.className=`state-banner ${kind}`;
  $('resultStateTitle').textContent=title;
  $('resultStateDetail').textContent=detail;
  box.hidden=false;
}
function clearResultState(){ $('resultState').hidden=true; $('resultState').className='state-banner'; }
function art(name,imageUrl){ return imageUrl ? `<img src="${imageUrl}" alt="${cleanName(name)}" loading="lazy">` : `<div class="fallback-art">${short(name)}</div>`; }
function defaultFloat(item){
  const min=Number(item.float_min),max=Number(item.float_max); const target=Math.max(min,Math.min(max,0.10)); return +target.toFixed(6);
}
function renderInputs(){
  $('inputGrid').innerHTML=state.slots.map((item,i)=>{
    if(!item) return `<article class="input-card empty"><span class="slot-number">${String(i+1).padStart(2,'0')}</span><span>+</span></article>`;
    return `<article class="input-card filled">
      <span class="slot-number">${String(i+1).padStart(2,'0')}</span><button class="remove-btn" data-remove="${i}" aria-label="Remover">×</button>
      <div class="skin-art">${art(item.skin_name,item.image_url)}</div>
      <div class="input-info"><h3 title="${item.skin_name}">${item.skin_name}</h3><div class="collection" title="${item.collection}">${item.collection}</div>
      <div class="float-row"><label>float</label><input data-float="${i}" type="number" step="0.000001" min="${item.float_min}" max="${item.float_max}" value="${item.float_value}"></div>
      <div class="input-foot"><span>${item.rarity}</span><span>${item.is_stattrak?'ST':'normal'}</span></div></div></article>`;
  }).join('');
  $('slotCounter').textContent=`${state.slots.filter(Boolean).length}/10`;
  document.querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{state.slots[+b.dataset.remove]=null;state.result=null;renderInputs();resetResult();});
  document.querySelectorAll('[data-float]').forEach(inp=>inp.onchange=()=>{const i=+inp.dataset.float; const it=state.slots[i]; const v=Number(inp.value); if(Number.isFinite(v)){it.float_value=Math.max(Number(it.float_min),Math.min(Number(it.float_max),v)); inp.value=it.float_value;} state.result=null; resetResult(); updateCompatibility();});
  updateCompatibility();
}
function updateCompatibility(){
  const filled=state.slots.filter(Boolean); let msg='Adicione 10 itens da mesma raridade e modalidade.'; let ok=false;
  if(filled.length){const ranks=new Set(filled.map(x=>x.rarity_rank)),modes=new Set(filled.map(x=>!!x.is_stattrak));
    if(ranks.size>1) msg='As raridades não combinam.'; else if(modes.size>1) msg='Normal e StatTrak não podem ser misturados.'; else if(filled.length<10) msg=`Composição compatível até aqui · faltam ${10-filled.length} slots.`; else {msg='10/10 · pronto para simular.';ok=true;}}
  $('compatibility').textContent=msg; $('simulateBtn').disabled=!ok;
}
async function search(){
  const q=$('skinSearch').value.trim(); if(q.length<2){showSearch([]);return;}
  $('searchBtn').textContent='…';
  try{const r=await fetch(`${API}?q=${encodeURIComponent(q)}&limit=18&ui=1`);const d=await r.json();showSearch(d.items||[]);}catch(e){showSearch([],true);}finally{$('searchBtn').textContent='Buscar';}
}
function showSearch(items,error=false){
  const box=$('searchResults'); if(error){box.innerHTML='<div class="search-item error">Falha ao consultar o catálogo.</div>';box.hidden=false;return;}
  if(!items.length){box.innerHTML='<div class="search-item"><span>Nenhum resultado</span></div>';box.hidden=false;return;}
  box.innerHTML=items.map((x,i)=>`<button class="search-item" data-pick="${i}"><span class="search-thumb">${art(x.skin_name,x.image_url)}</span><span class="search-copy"><strong>${x.skin_name}</strong><span class="meta">${x.collection} · ${x.rarity} · float ${x.float_min}–${x.float_max}</span></span><span class="badge">${x.is_stattrak?'ST':'NORMAL'}</span></button>`).join('');
  box.hidden=false; document.querySelectorAll('[data-pick]').forEach(b=>b.onclick=()=>pick(items[+b.dataset.pick]));
}
function pick(x){const idx=state.slots.findIndex(v=>!v);if(idx<0)return;state.slots[idx]={...x,float_value:defaultFloat(x),owned:false};$('searchResults').hidden=true;$('skinSearch').value='';renderInputs();}
function resetResult(){
  $('summarySection').hidden=true;
  $('outputsSection').hidden=true;
  $('engineStatus').textContent='aguardando contrato';
  clearResultState();
}
function colorForReturn(v){
  if(!hasNumber(v)) return {h:190,bg:'hsl(190 28% 15%)',border:'hsl(190 28% 32%)'};
  const n=Number(v); let h=n>=0?58+Math.min(n,80)/80*72:58-Math.min(Math.abs(n),100)/100*58; h=Math.max(0,Math.min(132,h));
  return {h,bg:`hsl(${h} 55% 15%)`,border:`hsl(${h} 70% 42%)`};
}
function patternFlag(name){return /(Case Hardened|Heat Treated|Fade|Doppler|Gamma Doppler|Marble Fade|Slaughter|Crimson Web)/i.test(name);}
function renderSummary(d){const e=d.economics||{};$('summarySection').hidden=false;$('economicCost').textContent=money(e.economic_cost_usd);$('profitChance').textContent=pct(e.profit_probability_pct);$('expectedValue').textContent=money(e.expected_value_usd);$('worstRecovery').textContent=pct(e.worst_recovery_pct);$('roi').textContent=pct(e.roi_pct);$('expectedProfit').textContent=money(e.expected_profit_usd);$('additionalSpend').textContent=money(e.additional_spend_usd);$('coverage').textContent=`${e.input_price_coverage} · ${e.output_price_coverage}`;}
function renderOutputs(outputs){
  $('outputsSection').hidden=false;$('outputGrid').innerHTML=outputs.map(x=>{const c=colorForReturn(x.return_pct);const partial=!hasNumber(x.return_pct);return `<article class="output-card ${partial?'partial':''}" style="--out-bg:${c.bg};--out-border:${c.border}">
    <div class="output-top"><span class="chance">${pct(x.probability_pct)}</span><span class="return-pill">${hasNumber(x.return_pct)?(Number(x.return_pct)>=0?'+':'')+Number(x.return_pct).toFixed(1)+'%':'N/D'}</span></div>
    <div class="skin-art">${art(x.skin_name,x.image_url)}</div><div class="output-body"><h3>${x.skin_name}</h3><div class="output-meta">${x.predicted_wear} · float ${Number(x.predicted_float).toFixed(5)}</div><div class="output-meta">${x.collection}</div>
    ${patternFlag(x.skin_name)?'<span class="pattern-flag">PATTERN-SENSITIVE · explorar depois</span>':''}
    <div class="output-money"><div><span>valor realizável</span><strong>${money(x.market?.realizable_usd)}</strong></div><div><span>resultado</span><strong>${hasNumber(x.profit_usd)?`${Number(x.profit_usd)>=0?'+':'-'}US$ ${Math.abs(Number(x.profit_usd)).toFixed(2)}`:'N/D'}</strong></div></div>
    <div class="output-actions"><button class="mini-btn" disabled title="Inspect exige um asset/listing real">Inspect</button><button class="mini-btn" disabled>abrir skin</button></div></div></article>`}).join('');
}
async function simulate(){
  const inputs=state.slots.map(x=>({market_key:x.market_key,float_value:Number(x.float_value),owned:!!x.owned}));
  $('simulateBtn').disabled=true;
  $('simulateBtn').textContent='Calculando…';
  $('engineStatus').textContent='calculando outputs e preços';
  clearResultState();
  try{
    const r=await fetch(`${API}?ui=1`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({inputs})});
    const d=await r.json().catch(()=>({status:'ERROR',error:'INVALID_RESPONSE'}));
    if(!r.ok||d.status!=='OK'){
      const code=d.error||`HTTP_${r.status}`;
      const friendly=ERROR_MESSAGES[code]||'Não foi possível avaliar este contrato com segurança.';
      $('summarySection').hidden=true;
      $('outputsSection').hidden=true;
      $('engineStatus').textContent='erro de avaliação';
      setResultState('error','Contrato não avaliado',`${friendly} · ${code}`);
      return;
    }
    state.result=d;
    if(Array.isArray(d.inputs)){
      d.inputs.forEach((x,i)=>{if(state.slots[i])state.slots[i]={...state.slots[i],image_url:x.image_url||state.slots[i].image_url};});
      renderInputs();
    }
    renderSummary(d);
    renderOutputs(d.outputs||[]);
    const economicsStatus=String(d.economics?.status||'').toUpperCase();
    if(economicsStatus==='COMPLETE'){
      $('engineStatus').textContent=`${d.outputs.length} outputs · cobertura completa`;
      setResultState('complete','COMPLETE · leitura econômica completa','Estrutura, preços e agregados econômicos estão cobertos para este contrato.');
    }else if(economicsStatus==='PARTIAL'){
      $('engineStatus').textContent=`${d.outputs.length} outputs · cobertura parcial`;
      setResultState('partial','PARTIAL · simulação estrutural válida','Probabilidades e floats podem ser exibidos, mas a cobertura de preço é incompleta. Métricas econômicas sem evidência permanecem N/D e os cards ficam visualmente neutros.');
    }else{
      $('summarySection').hidden=true;
      $('outputsSection').hidden=true;
      $('engineStatus').textContent='estado econômico inválido';
      setResultState('error','Resposta não reconhecida','O motor respondeu sem um estado econômico COMPLETE ou PARTIAL. Nada econômico foi inferido no frontend.');
    }
  }catch(e){
    $('summarySection').hidden=true;
    $('outputsSection').hidden=true;
    $('engineStatus').textContent='falha de conexão';
    setResultState('error','Não foi possível consultar o motor',String(e?.message||e));
  }finally{
    $('simulateBtn').disabled=false;
    $('simulateBtn').textContent='Simular contrato';
  }
}
async function loadDemo(){
  let base={collection:'The Arms Deal 2 Collection',skin_name:'FAMAS | Hexane',rarity:'Mil-Spec Grade',rarity_rank:3,float_min:0,float_max:.4,market_key:'FAMAS | Hexane',is_stattrak:false,image_url:null};
  try{const r=await fetch(`${API}?q=${encodeURIComponent('FAMAS | Hexane')}&limit=6&ui=1`);const d=await r.json();const found=(d.items||[]).find(x=>x.market_key==='FAMAS | Hexane'&&!x.is_stattrak);if(found)base=found;}catch(_){}
  state.slots=Array.from({length:10},()=>({...base,float_value:.10,owned:false}));state.result=null;renderInputs();resetResult();
}
$('searchBtn').onclick=search;$('skinSearch').addEventListener('keydown',e=>{if(e.key==='Enter')search();});let timer;$('skinSearch').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(search,280)});$('demoBtn').onclick=loadDemo;$('clearBtn').onclick=()=>{state.slots=Array(10).fill(null);state.result=null;renderInputs();resetResult();};$('simulateBtn').onclick=simulate;$('advancedBtn').onclick=()=>{const p=$('advancedPanel');p.hidden=!p.hidden;$('advancedBtn').textContent=p.hidden?'ver detalhes econômicos':'ocultar detalhes';};document.addEventListener('click',e=>{if(!e.target.closest('.search-shell'))$('searchResults').hidden=true;});
renderInputs();
